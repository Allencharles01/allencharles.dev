import { useEffect, useState } from "react";
import { useParams, Link } from "react-router-dom";
import api from "../services/api";

export default function ResultsPage() {
  const { attemptId } = useParams();
  const [result, setResult] = useState(null);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    api.get(`/api/quizzes/attempts/${attemptId}`)
      .then((res) => {
        setResult(res.data);
        setLoading(false);
      })
      .catch((err) => {
        console.error("Error fetching results:", err);
        setLoading(false);
      });
  }, [attemptId]);

  if (loading) return <p>Loading results...</p>;
  if (!result) return <p>Results not found.</p>;

  return (
    <div>
      <div className="hero-card" style={{ textAlign: "center", marginBottom: "30px" }}>
        <h2>Quiz Results</h2>
        <h1 style={{ fontSize: "3rem", margin: "10px 0" }}>
          {result.score} / {result.totalQuestions}
        </h1>
        <p>Keep practicing to improve your score!</p>
        <Link to="/quizzes">
          <button className="secondary-button" style={{ marginTop: "15px" }}>
            Back to Quizzes
          </button>
        </Link>
      </div>

      <h4 style={{ marginBottom: "20px" }}>Review Your Answers:</h4>

      {result.questions.map((q, index) => {
        const attempt = result.answers[index];
        const isCorrect = attempt.isCorrect;
        const userAnswerIndex = attempt.selectedIndex;
        const correctIndex = attempt.correctOptionIndex;

        return (
          <div key={index} className="result-card" style={{ borderLeft: `6px solid ${isCorrect ? "#4ade80" : "#f97373"}` }}>
            <p><strong>Question {index + 1}:</strong> {q.text}</p>
            
            <p style={{ margin: "8px 0", color: isCorrect ? "#4ade80" : "#f97373" }}>
              <strong>Your Answer:</strong> {q.options[userAnswerIndex]} 
              {isCorrect ? " ✓" : " ✗"}
            </p>

            {!isCorrect && (
              <p style={{ margin: "8px 0", color: "#38bdf8" }}>
                <strong>Correct Answer:</strong> {q.options[correctIndex]}
              </p>
            )}
          </div>
        );
      })}
    </div>
  );
}