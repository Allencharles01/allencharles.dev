import gradio as gr
import fitz  # PyMuPDF
import os
import requests
from dotenv import load_dotenv

# ============================================================
# Setup & Configuration
# ============================================================
load_dotenv()
AI_API_KEY = os.getenv("AI_API_KEY")
LOCAL_API_URL = "http://localhost:3000/api/ai"

# ============================================================
# Modern "Sakura-Dark" CSS
# ============================================================
custom_css = """
.gradio-container { 
    background: linear-gradient(135deg, #0f172a 0%, #1e1b4b 100%) !important; 
    color: white !important; 
    font-family: 'Inter', sans-serif; 
}
.main-title { text-align: center; color: #38bdf8; font-size: 3rem !important; font-weight: 800; margin-top: 20px; }
.sub-title { text-align: center; color: #94a3b8; margin-bottom: 40px; }
#forced-row { display: flex !important; gap: 20px !important; }
.tile-card { 
    background: rgba(30, 41, 59, 0.7) !important; 
    border: 1px solid rgba(56, 189, 248, 0.2) !important; 
    border-radius: 16px !important; padding: 20px !important; 
}
button.primary { 
    background: linear-gradient(90deg, #38bdf8 0%, #818cf8 100%) !important; 
    border: none !important; color: #0f172a !important; font-weight: 800 !important; 
}
#result-display { 
    background: rgba(15, 23, 42, 0.8) !important; 
    border: 2px solid #38bdf8 !important; 
    border-radius: 12px; padding: 25px; color: #f1f5f9; 
}
"""

# ============================================================
# Logic & Utility Functions
# ============================================================
def extract_text_from_pdf(pdf_file):
    if not pdf_file: return ""
    try:
        with fitz.open(pdf_file.name) as doc:
            return "".join([page.get_text() for page in doc]).strip()
    except Exception as e:
        return f"Error reading PDF: {str(e)}"

def call_local_ai(prompt):
    """Calls your local Node.js API which wraps Ollama."""
    headers = {
        "Authorization": f"Bearer {AI_API_KEY}",
        "Content-Type": "application/json"
    }
    payload = {"prompt": prompt}
    
    try:
        # Increased timeout to 300s for 8GB RAM systems
        response = requests.post(LOCAL_API_URL, headers=headers, json=payload, timeout=300)
        response.raise_for_status()
        return response.json().get('answer', "No response from AI."), None
    except requests.exceptions.Timeout:
        return None, "System is busy. Your local AI is taking too long to think. Please try again in a moment."
    except Exception as e:
        return None, f"Local API Error: {str(e)}. (Is 'node server.js' running?)"

def analyze_compatibility(job_desc, res_text, res_pdf):
    resume = res_text.strip() or extract_text_from_pdf(res_pdf)
    if not job_desc or not resume:
        return "### ⚠ Please provide both a Job Description and a Resume."
    
    # Forced template for the local model
    prompt = f"""
    Act as a Senior Recruiter. Analyze this Resume vs JD. 
    Use ONLY this structure. Use 🔹 for bullets. No extra talking.

    JD: {job_desc}
    RESUME: {resume}

    1. 🚀 **Compatibility Score**: [X]%
    🔹 (One line verdict)

    2. 🎯 **Things to focus on**:
    🔹 (Concept 1)
    🔹 (Concept 2)

    3. 💡 **Skills to Add**:
    🔹 (Skill 1)
    🔹 (Skill 2)

    4. 🛠️ **Resume Fix**:
    🔹 Add these keywords: [Keywords]
    🔹 If it’s not written, ATS assumes you don’t know it.

    5. 🏗️ **Projects**:
    🔹 **Project**: [Name]
    🔹 **Tech Stack**: [Tools]
    🔹 **Idea**: [1-sentence description]
    """
    
    output, error = call_local_ai(prompt)
    return output if not error else f"**Error:** {error}"

# ============================================================
# Gradio Interface
# ============================================================
with gr.Blocks(css=custom_css, title="CareerFit AI") as app:
    gr.Markdown("# 🚀 CareerFit AI", elem_classes=["main-title"])
    gr.Markdown("Hyper-personalize your resume for your dream role—locally & for free.", elem_classes=["sub-title"])

    with gr.Row(elem_id="forced-row"):
        with gr.Column(elem_classes=["tile-card"]):
            gr.Markdown("### 🎯 Target Job")
            job_input = gr.Textbox(placeholder="Paste JD here...", lines=10, show_label=False)
        with gr.Column(elem_classes=["tile-card"]):
            gr.Markdown("### 📄 Your Profile")
            resume_input = gr.Textbox(placeholder="Paste Resume text here...", lines=5, show_label=False)
            pdf_input = gr.File(label="Or Upload PDF", file_types=[".pdf"])
    
    run_btn = gr.Button("🚀 Run Local Analysis", variant="primary")
    
    gr.Markdown("## 📈 Compatibility Report")
    output_markdown = gr.Markdown(elem_id="result-display", value="*Ready for analysis...*")

    run_btn.click(
        analyze_compatibility, 
        inputs=[job_input, resume_input, pdf_input], 
        outputs=output_markdown
    )

if __name__ == "__main__":
    # Ensure you are in your venv and have run: pip install gradio pymupdf requests python-dotenv
    app.launch()