import { NavLink, useNavigate } from "react-router-dom";
import { useAuth } from "../App";

export default function Navbar() {
  const { user, logout } = useAuth();
  const navigate = useNavigate();

  return (
    <nav className="navbar">
      <div className="navbar-inner">
        {/* LEFT SIDE: Brand */}
        <div className="navbar-left">
          <button
            onClick={() => navigate("/")}
            className="navbar-brand-link"
            style={{ border: "none", background: "transparent", padding: 0, cursor: "pointer" }}
          >
            <span className="navbar-brand-main">codsoft jobboard</span>
          </button>
        </div>

        {/* RIGHT SIDE: Dynamic Buttons */}
        <div className="nav-links">
          <NavLink to="/" className={({ isActive }) => "nav-link " + (isActive ? "nav-link-active" : "")}>
            Home
          </NavLink>
          <NavLink to="/jobs" className={({ isActive }) => "nav-link " + (isActive ? "nav-link-active" : "")}>
            Jobs
          </NavLink>

          {/* Logic for logged-in users */}
          {user ? (
            <>
              {user.role === "candidate" && (
                <NavLink to="/candidate" className={({ isActive }) => "nav-link " + (isActive ? "nav-link-active" : "")}>
                  Candidate
                </NavLink>
              )}
              {user.role === "employer" && (
                <NavLink to="/employer" className={({ isActive }) => "nav-link " + (isActive ? "nav-link-active" : "")}>
                  Employer
                </NavLink>
              )}
              <button 
                onClick={() => { logout(); navigate("/"); }} 
                className="nav-link logout-btn"
                style={{ border: "none", background: "transparent", cursor: "pointer", color: "inherit" }}
              >
                Logout
              </button>
            </>
          ) : (
            /* Logic for guests */
            <NavLink to="/login" className={({ isActive }) => "nav-link " + (isActive ? "nav-link-active" : "")}>
              Log in
            </NavLink>
          )}
        </div>
      </div>
    </nav>
  );
}