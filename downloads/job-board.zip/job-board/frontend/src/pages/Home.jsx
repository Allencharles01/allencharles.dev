import { useEffect, useState } from "react";
import { Link } from "react-router-dom";
import api from "../api.js";

export default function Home() {
  const [latestJobs, setLatestJobs] = useState([]);
  const [loading, setLoading] = useState(true);
  const [expandedId, setExpandedId] = useState(null);

  useEffect(() => {
    const loadSpotlight = async () => {
      try {
        const { data } = await api.get("/api/jobs");
        // Show the 3 most recent posts
        setLatestJobs(data.slice(0, 3));
      } catch (err) {
        console.error("Spotlight Load Failed");
      } finally {
        setLoading(false);
      }
    };
    loadSpotlight();
  }, []);

  const toggleExpand = (id) => {
    setExpandedId(prev => (prev === id ? null : id));
  };

  return (
    <main className="home-page">
      <section className="home-hero">
        <h1 className="home-hero-title">
          Welcome to the Job Board <span>🚀</span>
        </h1>
        <p className="home-hero-text">
          Discover opportunities from top companies or post roles to find your next hire. 
          A streamlined platform for your career growth.
        </p>
      </section>

      <section className="home-latest">
        <div className="home-latest-divider" />
        <h2 className="home-latest-heading">Spotlight Roles</h2>

        {loading ? (
          <p className="home-latest-sub">Fetching latest opportunities...</p>
        ) : latestJobs.length === 0 ? (
          <p className="home-latest-sub">No openings currently listed. Check back soon!</p>
        ) : (
          <div className="jobs-grid home-latest-grid">
            {latestJobs.map((job) => {
              const active = expandedId === job._id;
              return (
                <div 
                  key={job._id} 
                  className={`job-card ${active ? 'active' : ''}`}
                  onClick={() => toggleExpand(job._id)}
                  style={{ cursor: "pointer" }}
                >
                  <h3 className="job-card-title">{job.title}</h3>
                  <p className="job-card-company">{job.company}</p>
                  <p className="job-card-location">📍 {job.location}</p>
                  
                  {active && (
                    <div className="expanded-content">
                      <hr style={{ border: "0", borderTop: "1px solid #334155", margin: "12px 0" }} />
                      <p className="home-job-description">{job.description}</p>
                      <Link to={`/jobs/${job._id}`} className="home-job-view-link">
                        Full details & Apply →
                      </Link>
                    </div>
                  )}
                </div>
              );
            })}
          </div>
        )}

        <div className="home-browse-wrapper">
          <Link to="/jobs" className="home-browse-btn">Explore All Jobs</Link>
        </div>
      </section>
    </main>
  );
}