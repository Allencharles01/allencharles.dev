import { useState } from "react";
import { useNavigate } from "react-router-dom";
import api from "../api.js";
import { useAuth } from "../App.jsx";

export default function Login() {
  const [role, setRole] = useState("candidate"); 
  const [step, setStep] = useState("request"); // 'request' or 'verify'
  const [email, setEmail] = useState("");
  const [otp, setOtp] = useState("");
  const [status, setStatus] = useState({ type: "", msg: "" });
  const [busy, setBusy] = useState(false);

  const { login } = useAuth();
  const navigate = useNavigate();

  const triggerOtp = async (e) => {
    e.preventDefault();
    if (!email) return setStatus({ type: "error", msg: "Please enter your email." });

    setBusy(true);
    try {
      await api.post("/api/auth/send-otp", { email: email.trim(), role });
      setStep("verify");
      setStatus({ type: "info", msg: "Code sent! Please check your inbox." });
    } catch (err) {
      setStatus({ type: "error", msg: "Failed to send code. Try again." });
    } finally {
      setBusy(false);
    }
  };

  const confirmOtp = async (e) => {
    e.preventDefault();
    setBusy(true);
    try {
      const { data } = await api.post("/api/auth/verify-otp", { email: email.trim(), otp });
      login(data.role, data.email);
      navigate(data.role === "employer" ? "/employer" : "/candidate");
    } catch (err) {
      setStatus({ type: "error", msg: err.response?.data?.message || "Invalid code." });
    } finally {
      setBusy(false);
    }
  };

  return (
    <main className="app-page app-page-center">
      <div className="login-card">
        <h1 className="login-title">Sign In</h1>
        <p className="login-subtitle">Secure passwordless login via OTP</p>

        <div className="login-role-toggle">
          {["candidate", "employer"].map(r => (
            <button
              key={r}
              className={`login-role-btn ${role === r ? 'is-active' : ''}`}
              onClick={() => setRole(r)}
            >
              {r.charAt(0).toUpperCase() + r.slice(1)}
            </button>
          ))}
        </div>

        {status.msg && (
          <div className={`login-message login-message-${status.type}`}>
            {status.msg}
          </div>
        )}

        {step === "request" ? (
          <form onSubmit={triggerOtp} className="login-form">
            <label className="login-label">
              Email Address
              <input 
                type="email" 
                className="login-input" 
                placeholder="allen@example.com"
                value={email}
                onChange={(e) => setEmail(e.target.value)}
              />
            </label>
            <button className="login-primary-btn" disabled={busy}>
              {busy ? "Sending..." : "Get Access Code"}
            </button>
          </form>
        ) : (
          <form onSubmit={confirmOtp} className="login-form">
            <p style={{ fontSize: '0.8rem', color: '#94a3b8' }}>Sent to: <b>{email}</b></p>
            <input 
              type="text" 
              className="login-input" 
              placeholder="Enter 6-digit code"
              maxLength={6}
              value={otp}
              onChange={(e) => setOtp(e.target.value)}
            />
            <button className="login-primary-btn" disabled={busy}>Verify & Log In</button>
            <button type="button" className="login-secondary-btn" onClick={() => setStep("request")}>
              Use different email
            </button>
          </form>
        )}
      </div>
    </main>
  );
}