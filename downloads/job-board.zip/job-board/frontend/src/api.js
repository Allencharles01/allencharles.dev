import axios from "axios";

// Determine if we are running locally or in production
const isLocal = window.location.hostname === "localhost";
const BASE_URL = isLocal 
  ? "http://localhost:5000" 
  : "https://your-production-backend.com"; // Update this when you deploy backend

const api = axios.create({
  baseURL: BASE_URL,
  withCredentials: true,
  headers: {
    "Content-Type": "application/json",
  }
});

// Interceptor for cleaner error logging
api.interceptors.response.use(
  (response) => response,
  (error) => {
    console.error(`API Error [${error.config.url}]:`, error.response?.data || error.message);
    return Promise.reject(error);
  }
);

export default api;