🚀 Job Board Platform

A full-stack Job Board web application where:

* 👨‍💼 Employers can post, edit, and manage jobs
* 👩‍💻 Candidates can browse jobs and apply
* 📄 Resumes can be uploaded
* 📧 Email & OTP system powered by Resend
* 🗄 MongoDB Atlas for cloud database
* 🔐 Authentication with role-based access

Live-ready and production deployable.

---

# 📌 What Is This Project?

This is a MERN-style full-stack job board platform built with:

* **Frontend**: React (Vite)
* **Backend**: Node.js + Express
* **Database**: MongoDB Atlas
* **Email Service**: Resend API
* **Auth**: JWT-based authentication
* **Deployment Ready**: NGINX + VPS compatible

It supports:

* Candidate & Employer roles
* Job CRUD
* Resume uploads
* Application tracking
* Status updates (Accept / Reject)

---

# 🧰 Pre-Requisites

Install these before running:

* Node.js (v18+ recommended)
* npm
* Git
* MongoDB Atlas account
* Resend API key

Optional (for production):

* VPS (Ubuntu recommended)
* NGINX
* PM2

Check versions:

```bash
node -v
npm -v
```

---

# 💻 Installation & Setup

Clone the repository:

```bash
git clone https://github.com/YOUR_USERNAME/job-board.git
cd job-board
```

---

## 🔹 Backend Setup

```bash
cd backend
npm install
```

Create a `.env` file inside backend folder:

```
PORT=5000
MONGO_URI=your_mongodb_atlas_uri
RESEND_API_KEY=your_resend_api_key
JWT_SECRET=your_secret_key
```

Start backend:

```bash
npm run dev
```

Backend runs at:

```
http://localhost:5000
```

---

## 🔹 Frontend Setup

Open new terminal:

```bash
cd frontend
npm install
npm run dev
```

Frontend runs at:

```
http://localhost:5173
```

---

# 🖥 OS-Specific Setup

## 🐧 Linux (Ubuntu/Fedora)

* Install Node via:

```bash
sudo apt install nodejs npm
```

or use nvm (recommended)

## 🪟 Windows

* Download Node.js from:
  [https://nodejs.org](https://nodejs.org)
* Use Git Bash or PowerShell
* Follow same steps above

## 🍎 MacOS

* Install Node using Homebrew:

```bash
brew install node
```

* Follow same backend/frontend steps

---

# 📦 Production Build

Inside frontend:

```bash
npm run build
```

Use NGINX to serve the `dist` folder and reverse proxy `/api` to backend.

Use PM2 for backend:

```bash
pm2 start server.js
```

---

# 🧪 Troubleshooting

### ❌ MongoDB connection error

Check:

* Correct MONGO_URI
* Whitelisted IP in MongoDB Atlas

### ❌ CORS error

Ensure backend allows:

```
origin: "http://localhost:5173"
```

(or your production domain)

### ❌ Email not sending

Check:

* Valid RESEND_API_KEY
* Domain verified in Resend

### ❌ Resume not opening

Ensure backend includes:

```js
app.use("/uploads", express.static("uploads"));
```

---

# 🛠 Libraries Used

Frontend:

* React
* React Router
* Axios

Backend:

* Express
* Mongoose
* JWT
* Multer (file upload)
* Resend

---

# 🌐 Connect With Me

💼 LinkedIn
[https://www.linkedin.com/in/YOUR_LINK](https://www.linkedin.com/in/allencharles01/)

💻 GitHub
[https://github.com/YOUR_USERNAME](https://github.com/Allencharles01)

