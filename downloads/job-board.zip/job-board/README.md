# job-board-platform
Full-stack MERN Job Board platform with role-based authentication, resume uploads, employer dashboard, and production-ready VPS deployment.
