import express from "express";
import Application from "../models/Application.js";
import uploadMiddleware from "../middleware/uploadMiddleware.js";
import sendEmail from "../utils/sendEmail.js";

const router = express.Router();

/**
 * Handle new applications with file upload
 */
router.post("/", uploadMiddleware.single("resume"), async (req, res) => {
  try {
    const { jobId, fullName, email, jobTitle, company } = req.body;

    if (!jobId || !fullName || !email || !req.file) {
      return res.status(400).json({ message: "All fields including resume are required." });
    }

    const application = new Application({
      jobId,
      candidateName: fullName,
      candidateEmail: email.toLowerCase(),
      resumePath: `/uploads/resumes/${req.file.filename}`,
      jobTitle: jobTitle || "Role not specified",
      company: company || "Company not specified",
      status: "pending",
    });

    await application.save();

    // Notify candidate - Non-blocking
    sendEmail(
      application.candidateEmail,
      `Application Received: ${application.jobTitle}`,
      `Hi ${application.candidateName},\n\nWe've received your application for ${application.jobTitle} at ${application.company}. The employer will review it shortly.\n\nBest of luck!`
    ).catch(e => console.error("Email Delivery Failed:", e.message));

    res.status(201).json(application);
  } catch (err) {
    console.error("Submission Error:", err);
    res.status(500).json({ message: "Internal error during application submission." });
  }
});

/**
 * Employer: Update application status (Accept/Reject)
 */
router.post("/decision", async (req, res) => {
  try {
    const { applicationId, status } = req.body;
    
    if (!["accepted", "rejected", "pending"].includes(status)) {
      return res.status(400).json({ message: "Invalid status provided." });
    }

    const app = await Application.findByIdAndUpdate(applicationId, { status }, { new: true });
    if (!app) return res.status(404).json({ message: "Record not found." });

    // Send decision email
    const statusLabel = status.toUpperCase();
    sendEmail(
      app.candidateEmail,
      `Update: Your application for ${app.jobTitle}`,
      `Hi ${app.candidateName},\n\nYour application for "${app.jobTitle}" at ${app.company} has been updated to: ${statusLabel}.\n\nBest regards.`
    ).catch(e => console.error("Status Email Error:", e.message));

    res.json(app);
  } catch (err) {
    res.status(500).json({ message: "Error updating candidate status." });
  }
});

// ... Dashboard Fetchers (Keep identical logic but cleaned up code)
router.get("/candidate", async (req, res) => {
  const { email } = req.query;
  if (!email) return res.status(400).json({ message: "Email required." });
  const list = await Application.find({ candidateEmail: email.toLowerCase() }).sort({ createdAt: -1 });
  res.json(list);
});

router.get("/employer", async (req, res) => {
  const { company } = req.query;
  const list = await Application.find({ company: { $regex: new RegExp(`^${company}$`, "i") } }).sort({ createdAt: -1 });
  res.json(list);
});

router.get("/by-job", async (req, res) => {
  const list = await Application.find({ jobId: req.query.jobId }).sort({ createdAt: -1 });
  res.json(list);
});

router.get("/:id", async (req, res) => {
  const app = await Application.findById(req.params.id);
  app ? res.json(app) : res.status(404).json({ message: "Not found" });
});

router.delete("/:id", async (req, res) => {
  await Application.findByIdAndDelete(req.params.id);
  res.json({ message: "Application withdrawn." });
});

export default router;