import express from "express";
import dotenv from "dotenv";
import cors from "cors";
import cookieParser from "cookie-parser";
import path from "path";
import fs from "fs";

// Route Imports
import applicationRoutes from "./routes/applications.js";
import authRoutes from "./routes/authRoutes.js";
import connectDB from "./config/db.js";
import Job from "./models/Job.js";

dotenv.config();

const app = express();
const PORT = process.env.PORT || 5000;

// --- Persistence & Storage ---
const uploadPath = path.join(process.cwd(), "uploads/resumes");
if (!fs.existsSync(uploadPath)) {
  fs.mkdirSync(uploadPath, { recursive: true });
}

// --- Middleware Stack ---
app.use(express.json());
app.use(cookieParser());

const allowedOrigins = [
  "http://localhost:5173",
  "https://allenjobboard.netlify.app",
];

app.use(cors({
  origin: (origin, callback) => {
    // Allow server-to-server or local health checks (no origin)
    if (!origin || allowedOrigins.includes(origin)) {
      return callback(null, true);
    }
    return callback(new Error("Blocked by CORS policy"));
  },
  credentials: true,
}));

// Static file serving for resumes
app.use("/uploads", express.static("uploads"));

// --- API Routes ---
app.get("/healthz", (req, res) => res.status(200).send("Server is healthy"));
app.use("/api/auth", authRoutes);
app.use("/api/applications", applicationRoutes);

/**
 * JOB MANAGEMENT ENDPOINTS
 * These remain in server.js per your original structure but with improved logic
 */

// Fetch all jobs (Newest first)
app.get("/api/jobs", async (req, res) => {
  try {
    const jobs = await Job.find().sort({ createdAt: -1 });
    res.json(jobs);
  } catch (err) {
    console.error("Fetch Jobs Error:", err);
    res.status(500).json({ message: "Unable to retrieve job listings" });
  }
});

// Company-specific filtering
app.get("/api/jobs/by-company", async (req, res) => {
  const { company } = req.query;
  if (!company) return res.status(400).json({ message: "Company parameter is required" });

  try {
    const jobs = await Job.find({
      company: { $regex: new RegExp(`^${company}$`, "i") },
    }).sort({ createdAt: -1 });
    res.json(jobs);
  } catch (err) {
    res.status(500).json({ message: "Search by company failed" });
  }
});

// Get detailed job info
app.get("/api/jobs/:id", async (req, res) => {
  try {
    const job = await Job.findById(req.params.id);
    if (!job) return res.status(404).json({ message: "Job not found" });
    res.json(job);
  } catch (err) {
    res.status(500).json({ message: "Error retrieving job details" });
  }
});

// Post a new opening
app.post("/api/jobs", async (req, res) => {
  try {
    const newJob = await Job.create(req.body);
    res.status(201).json(newJob);
  } catch (err) {
    res.status(500).json({ message: "Failed to publish job" });
  }
});

// Update existing job
app.put("/api/jobs/:id", async (req, res) => {
  try {
    const updated = await Job.findByIdAndUpdate(req.params.id, req.body, {
      new: true,
      runValidators: true,
    });
    if (!updated) return res.status(404).json({ message: "Job record not found" });
    res.json(updated);
  } catch (err) {
    res.status(500).json({ message: "Update failed" });
  }
});

// Remove job
app.delete("/api/jobs/:id", async (req, res) => {
  try {
    const deleted = await Job.findByIdAndDelete(req.params.id);
    if (!deleted) return res.status(404).json({ message: "Job not found" });
    res.json({ message: "Listing successfully removed" });
  } catch (err) {
    res.status(500).json({ message: "Deletion failed" });
  }
});

// Root check
app.get("/", (req, res) => res.send("🚀 CodSoft JobBoard API Active"));

// --- Database & Server Ignition ---
connectDB().then(() => {
  app.listen(PORT, () => {
    console.log(`\n--- Server Status ---`);
    console.log(`🚀 Port: ${PORT}`);
    console.log(`📁 Uploads: ${uploadPath}`);
    console.log(`----------------------\n`);
  });
}).catch(err => {
  console.error("Critical Failure: Database connection could not be established.");
  process.exit(1);
});