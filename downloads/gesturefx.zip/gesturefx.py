import streamlit as st
import cv2
import mediapipe as mp
import time

# Streamlit Page Setup
st.set_page_config(layout="centered", page_title="Hand Gesture Filter")
st.title("🖐️ Gesture Controlled Streamlit FX")

run = st.checkbox('🎥 Start Webcam')
frame_window = st.image([])

# MediaPipe Setup
mp_hands = mp.solutions.hands
hands = mp_hands.Hands(min_detection_confidence=0.7, max_num_hands=1)
mp_draw = mp.solutions.drawing_utils

cap = cv2.VideoCapture(0)

# State Variables
if 'active_gesture' not in st.session_state:
    st.session_state.active_gesture = None
    st.session_state.start_time = None
    st.session_state.triggered = False

def set_theme(mode="light"):
    color = "#111" if mode == "dark" else "white"
    text = "white" if mode == "dark" else "black"
    st.markdown(f"""
        <style>
            .stApp {{ background-color: {color}; color: {text}; }}
        </style>
    """, unsafe_allow_html=True)

HOLD_TIME = 2.0  # Seconds to hold gesture

while run:
    success, frame = cap.read()
    if not success: break

    frame = cv2.flip(frame, 1)
    h, w, c = frame.shape
    rgb = cv2.cvtColor(frame, cv2.COLOR_BGR2RGB)
    results = hands.process(rgb)

    detected_gesture = None
    wrist_pos = None

    if results.multi_hand_landmarks:
        for hand_landmarks in results.multi_hand_landmarks:
            mp_draw.draw_landmarks(frame, hand_landmarks, mp_hands.HAND_CONNECTIONS)
            lm = hand_landmarks.landmark
            
            # Get wrist position for the UI circle
            wrist_pos = (int(lm[0].x * w), int(lm[0].y * h))

            # Gesture Logic
            thumb = lm[4]; index = lm[8]; middle = lm[12]; ring = lm[16]; pinky = lm[20]
            idx_mcp = lm[5]; mid_mcp = lm[9]; rng_mcp = lm[13]; pnk_mcp = lm[17]

            if thumb.y < index.y and thumb.y < middle.y:
                detected_gesture = "thumbs_up"
            elif (index.y < ring.y and middle.y < ring.y and thumb.y > index.y):
                detected_gesture = "peace"
            elif all(tip.y > mcp.y for tip, mcp in zip([index, middle, ring, pinky], [idx_mcp, mid_mcp, rng_mcp, pnk_mcp])):
                detected_gesture = "fist"
            elif all(tip.y < mcp.y for tip, mcp in zip([index, middle, ring, pinky], [idx_mcp, mid_mcp, rng_mcp, pnk_mcp])):
                detected_gesture = "palm"

    # --- TIMER & VISUALIZATION LOGIC ---
    if detected_gesture and detected_gesture == st.session_state.active_gesture:
        if not st.session_state.triggered:
            elapsed = time.time() - st.session_state.start_time
            
            # Calculate countdown (from 360 down to 0)
            remaining_ratio = max(0, (HOLD_TIME - elapsed) / HOLD_TIME)
            angle = int(remaining_ratio * 360)

            # Draw the loading circle around the wrist
            if wrist_pos:
                # Background circle (faint)
                cv2.circle(frame, wrist_pos, 40, (200, 200, 200), 2)
                # The "Clock" timer arc
                cv2.ellipse(frame, wrist_pos, (40, 40), -90, 0, angle, (0, 255, 0), 5)
            
            # Trigger effect when timer hits zero
            if elapsed >= HOLD_TIME:
                if detected_gesture == "thumbs_up": st.balloons()
                elif detected_gesture == "peace": st.snow()
                elif detected_gesture == "fist": set_theme("dark")
                elif detected_gesture == "palm": set_theme("light")
                
                st.session_state.triggered = True
    else:
        # Reset if hand leaves or gesture changes
        st.session_state.active_gesture = detected_gesture
        st.session_state.start_time = time.time()
        st.session_state.triggered = False

    frame_window.image(frame, channels="BGR")

cap.release()